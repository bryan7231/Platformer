package test;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.geom.*;

public abstract class Entity {
	protected float x, y;
	protected int width, height;
	protected Rectangle boundingBox;
	
	
	public Entity(float x, float y, int width, int height) {
		this.x = x;
		this.y = y;
		this.height = height;
		this.width = width;
		
		boundingBox = new Rectangle(0, 0, width, height);
	}
	
	public Shape getBoundingBox() {
		return this.boundingBox;
	}
	
	public void update(int delta) {
		
	}
	
	public void render(Graphics g) {
		
	}
	
}
