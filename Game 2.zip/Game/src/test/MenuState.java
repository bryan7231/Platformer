package test;

import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.font.effects.ColorEffect;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;

public class MenuState extends BasicGameState{
	
	java.awt.Font UIFont1;
	java.awt.Font UIFont2;
	java.awt.Font UIFont3;
	org.newdawn.slick.UnicodeFont Title;
	org.newdawn.slick.UnicodeFont Description;
	org.newdawn.slick.UnicodeFont Start;

	public void init(GameContainer container, StateBasedGame arg1) throws SlickException {
		try{
	        UIFont1 = java.awt.Font.createFont(java.awt.Font.TRUETYPE_FONT,
	        org.newdawn.slick.util.ResourceLoader.getResourceAsStream("data/Roboto/Roboto-Thin.ttf"));
	        UIFont1 = UIFont1.deriveFont(java.awt.Font.BOLD, 40.f); //You can change "PLAIN" to "BOLD" or "ITALIC"... and 16.f is the size of your font
	        
	        UIFont2 = java.awt.Font.createFont(java.awt.Font.TRUETYPE_FONT,
	        org.newdawn.slick.util.ResourceLoader.getResourceAsStream("data/Roboto/Roboto-Thin.ttf"));
	    	UIFont2 = UIFont1.deriveFont(java.awt.Font.PLAIN, 20.f); //You can change "PLAIN" to "BOLD" or "ITALIC"... and 16.f is the size of your font
	    	
	    	UIFont3 = java.awt.Font.createFont(java.awt.Font.TRUETYPE_FONT,
	    	org.newdawn.slick.util.ResourceLoader.getResourceAsStream("data/Roboto/Roboto-Thin.ttf"));
	    	UIFont3 = UIFont1.deriveFont(java.awt.Font.BOLD, 16.f); //You can change "PLAIN" to "BOLD" or "ITALIC"... and 16.f is the size of your font
	    	
	        Title = new org.newdawn.slick.UnicodeFont(UIFont1);
	        Title.addAsciiGlyphs();
	        Title.getEffects().add(new ColorEffect(java.awt.Color.black)); //You can change your color here, but you can also change it in the render{ ... }
	        Title.addAsciiGlyphs();
	        Title.loadGlyphs();
	        
	        Description = new org.newdawn.slick.UnicodeFont(UIFont2);
	        Description.addAsciiGlyphs();
	        Description.getEffects().add(new ColorEffect(java.awt.Color.black)); //You can change your color here, but you can also change it in the render{ ... }
	        Description.addAsciiGlyphs();
	        Description.loadGlyphs();
	        
	        Start = new org.newdawn.slick.UnicodeFont(UIFont3);
	        Start.addAsciiGlyphs();
	        Start.getEffects().add(new ColorEffect(java.awt.Color.black)); //You can change your color here, but you can also change it in the render{ ... }
	        Start.addAsciiGlyphs();
	        Start.loadGlyphs();
	        
	    }catch(Exception e){
	            e.printStackTrace();
	    }
	}
	
	public void update(GameContainer container, StateBasedGame sbg, int arg2) throws SlickException {
		Input input = container.getInput();
		if(input.isKeyPressed(Input.KEY_ENTER)) {
			sbg.enterState(0, new FadeOutTransition(), new FadeInTransition());
		}
	}
	
	public void render(GameContainer container, StateBasedGame sbg, Graphics g) throws SlickException {
		g.setBackground(Color.white);
		Title.drawString(530, 200, "Morning Rumble!");
		Description.drawString(460, 330, "A platformer game designed and coded by Bryan Zou");
		Start.drawString(600, 630, "Press ENTER to start!");
	}

	public int getID() {
		return 1;
	}

}
