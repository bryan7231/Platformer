package test;


import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

public class SetupClass extends StateBasedGame{
	
	public SetupClass(String title) {
		super(title);
	}
	
	public static void main(String[] args) throws SlickException {
		AppGameContainer app = new AppGameContainer(new SetupClass("Setup Test"));
		
		app.setDisplayMode(1340, 908, false);
		app.setShowFPS(false);
		app.setVSync(true);
		app.setAlwaysRender(true);
		
		app.start();
	}

	public void initStatesList(GameContainer container) throws SlickException {
		this.addState(new MenuState());
		this.addState(new GameState());
		this.addState(new retryState());
	}

	

	

	
}
