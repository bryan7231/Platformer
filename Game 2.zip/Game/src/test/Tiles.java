package test;

import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;

public class Tiles extends Entity{
	private int type;
	private int rotation;
	private SpriteSheet tile;
	
	public Tiles(float x, float y, int width, int height, int type, int rotation) throws SlickException {
		super(x, y, width, height);
		this.type = type;
		this.rotation = rotation;
		
		boundingBox.setX(x);
		boundingBox.setY(y);
		boundingBox.setHeight(32);
		boundingBox.setWidth(32);
		
		tile = new SpriteSheet("data/tiles.png", 32, 32);
	}
	@Override 
	public void render(Graphics g) {
		tile.startUse();
		tile.getSubImage(type, rotation).drawEmbedded(x, y, 32, 32);
		tile.endUse();
	
	}
	
	

}
