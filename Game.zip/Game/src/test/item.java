package test;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;

public class item extends Entity{
	private int type;
	private SpriteSheet item;
	public item(float x, float y, int width, int height, int type) throws SlickException {
		super(x, y, width, height);
		this.type = type;
		boundingBox.setX(x);
		boundingBox.setY(y);
		boundingBox.setHeight(32);
		boundingBox.setWidth(32);
		
		item = new SpriteSheet("data/item.png", 32, 32);
	}
	
	@Override 
	public void render(Graphics g) {
		item.startUse();
		item.getSubImage(type, 0).drawEmbedded(x, y, 32, 32);
		item.endUse();
	}

	public int getType() {
		return type;
	}

}
