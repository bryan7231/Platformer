package test;

import java.util.ArrayList;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;

public class GameState extends BasicGameState{
	Entity player, testTile;
	int level = 1;
	ArrayList<Entity> levelTile;
	Image background;
	item item;
	
	public void init(GameContainer container, StateBasedGame sbg) throws SlickException {
		
		levelTile = initLevel(level, sbg);
		player = new Player(100, 740, 128, 256, initLevel(level), container, item, 0);
	}

	public void update(GameContainer arg0, StateBasedGame arg1, int delta) throws SlickException {
		player.update(delta);
	}
	
	public void render(GameContainer arg0, StateBasedGame arg1, Graphics g) throws SlickException {
		LevelRender(level, g);
		player.render(g);
		if (player.x > 1340) {
			level++;
			init(arg0, arg1);
		}
	}

	public int getID() {

		return 0;
	}
	
	public ArrayList<Entity> initLevel(int level, StateBasedGame sbg) throws SlickException {
		switch (level) {
			case 0:
				ArrayList<Entity> test = new ArrayList<>();
				
				test.add(0, new Tiles(0, 832, 32, 32, 0, 0));
				for (int i = 1; i < 41; i++) {
					test.add(new Tiles(32*i, 832, 32, 32, 1, 0));
				}
				test.add(41, new Tiles(32*41, 832, 32, 32, 0, 1));
				
				return test;
			case 1:
				item = new item(100, 78, 32, 32, 0);
				background = new Image("data/Bedroom.png");
				ArrayList<Entity> Level1 = new ArrayList<>();
				Level1.add(0, new Tiles(0, 832, 32, 32, 0, 0));
				for (int i = 1; i < 41; i++) {
					Level1.add(new Tiles(32*i, 832, 32, 32, 1, 0));
				}
				Level1.add(41, new Tiles(32*41, 832, 32, 32, 0, 1));
				Level1.add(new Tiles(300, 700, 32, 32, 0, 0));
				Level1.add(new Tiles(332, 700, 32, 32, 1, 0));
				Level1.add(new Tiles(364, 700, 32, 32, 1, 0));
				Level1.add(new Tiles(396, 700, 32, 32, 1, 0));
				Level1.add(new Tiles(428, 700, 32, 32, 0, 1));
				for (int i = 4; i < 28; i++) {
					Level1.add(new Tiles(1340, 32*i, 32, 32, 2, 0));
				}
				Level1.add(new Tiles(1212, 128, 32, 32, 0, 0));
				Level1.add(new Tiles(1244, 128, 32, 32, 1, 0));
				Level1.add(new Tiles(1276, 128, 32, 32, 1, 0));
				Level1.add(new Tiles(1308, 128, 32, 32, 1, 0));
				Level1.add(new Tiles(1340, 128, 32, 32, 0, 1));
				
				Level1.add(new Tiles(500, 500, 32, 32, 0, 0));
				Level1.add(new Tiles(532, 500, 32, 32, 1, 0));
				Level1.add(new Tiles(564, 500, 32, 32, 1, 0));
				Level1.add(new Tiles(596, 500, 32, 32, 1, 0));
				Level1.add(new Tiles(628, 500, 32, 32, 0, 1));
				
				Level1.add(new Tiles(780, 400, 32, 32, 0, 0));
				Level1.add(new Tiles(812, 400, 32, 32, 1, 0));
				Level1.add(new Tiles(844, 400, 32, 32, 1, 0));
				Level1.add(new Tiles(876, 400, 32, 32, 1, 0));
				Level1.add(new Tiles(908, 400, 32, 32, 0, 1));
				
				Level1.add(new Tiles(500, 240, 32, 32, 0, 0));
				Level1.add(new Tiles(532, 240, 32, 32, 1, 0));
				Level1.add(new Tiles(564, 240, 32, 32, 1, 0));
				Level1.add(new Tiles(596, 240, 32, 32, 1, 0));
				Level1.add(new Tiles(628, 240, 32, 32, 0, 1));
				
				Level1.add(new Tiles(4, 100, 32, 32, 0, 0));
				Level1.add(new Tiles(36, 100, 32, 32, 1, 0));
				Level1.add(new Tiles(68, 100, 32, 32, 1, 0));
				Level1.add(new Tiles(100, 100, 32, 32, 1, 0));
				Level1.add(new Tiles(132, 100, 32, 32, 1, 0));
				Level1.add(new Tiles(164, 100, 32, 32, 3, 1));
				Level1.add(new Tiles(164, 132, 32, 32, 1, 2));
				Level1.add(new Tiles(164, 164, 32, 32, 0, 2));
				return Level1;
			case 2:
				item = new item(100, 100, 32, 32, 1);
				background = new Image("data/Bathroom.png");
				ArrayList<Entity> Level2 = new ArrayList<>();
				Level2.add(0, new Tiles(0, 832, 32, 32, 0, 0));
				for (int i = 1; i < 41; i++) {
					Level2.add(new Tiles(32*i, 832, 32, 32, 1, 0));
				}
				Level2.add(41, new Tiles(32*41, 832, 32, 32, 0, 1));
				for (int i = 4; i < 28; i++) {
					Level2.add(new Tiles(32, 32*i, 32, 32, 2, 1));
				}
				for (int i = 4; i < 28; i++) {
					Level2.add(new Tiles(1340, 32*i, 32, 32, 2, 0));
				}
				Level2.add(new Tiles(500, 500, 32, 32, 0, 0));
				Level2.add(new Tiles(532, 500, 32, 32, 1, 0));
				Level2.add(new Tiles(564, 500, 32, 32, 1, 0));
				Level2.add(new Tiles(596, 500, 32, 32, 1, 0));
				Level2.add(new Tiles(628, 500, 32, 32, 0, 1));
				Level2.add(new Tiles(4, 100, 32, 32, 0, 0));
				Level2.add(new Tiles(36, 100, 32, 32, 1, 0));
				Level2.add(new Tiles(68, 100, 32, 32, 1, 0));
				Level2.add(new Tiles(100, 100, 32, 32, 1, 0));
				Level2.add(new Tiles(132, 100, 32, 32, 1, 0));
				Level2.add(new Tiles(164, 100, 32, 32, 3, 1));
				Level2.add(new Tiles(164, 132, 32, 32, 1, 2));
				Level2.add(new Tiles(164, 164, 32, 32, 0, 2));
				Level2.add(new Tiles(1212, 128, 32, 32, 0, 0));
				Level2.add(new Tiles(1244, 128, 32, 32, 1, 0));
				Level2.add(new Tiles(1276, 128, 32, 32, 1, 0));
				Level2.add(new Tiles(1308, 128, 32, 32, 1, 0));
				Level2.add(new Tiles(1340, 128, 32, 32, 0, 1));
				
				return Level2;
			case 3:
				sbg.enterState(2, new FadeOutTransition(), new FadeInTransition());
				
				
		}
		return null;
	}
	
	public void LevelRender(int level, Graphics g) throws SlickException {
	
		switch (level) {
			case 0:
				
				for (int i = 0; i<levelTile.size(); i++) {
					Entity a = levelTile.get(i);
					a.render(g);
				}
				break;
			case 1:
				
				g.drawImage(background, 0, 0);
				for (int i = 0; i<levelTile.size(); i++) {
					Entity a = levelTile.get(i);
					a.render(g);
				}
				item.render(g);
				break;
			case 2: 
				g.drawImage(background, 0, 0);
				for (int i = 0; i<levelTile.size(); i++) {
					Entity a = levelTile.get(i);
					a.render(g);
				}
				item.render(g);
		}
	}
 	
}
