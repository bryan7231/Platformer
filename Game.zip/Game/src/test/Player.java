package test;

import java.util.ArrayList;

import org.newdawn.slick.Animation;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

public class Player extends Entity{
	
	private SpriteSheet player_left, player_right;
	private Animation animation_left, animation_right;
	private ArrayList<Entity> TileList;
	private GameContainer container;
	private int count = 0;
	private int DoubleJumps = 0;
	private int JumpCount = 0;
	private int temp1, temp2;
	private int xVel = 0;
	private int yVel = 3;
	private int TopSpeed = 10;
	private int JumpHeight = 20;
	private int Speed = 2;
	private Boolean left, right, down, up;
	private Boolean direction = null;
	private StateBasedGame a;
	private item item;
	
	public Player(float x, float y, int width, int height, ArrayList<Entity> TileList, GameContainer container, item item, int count) throws SlickException {
		super(x, y, width, height);
		this.TileList = TileList;
		this.a = a;
		this.container = container;
		this.item = item;
		this.count = count;
		
		boundingBox.setWidth(25);
		boundingBox.setHeight(60);
		
		player_left = new SpriteSheet("data/player_left.png", 64, 128);
		player_right = new SpriteSheet("data/player_right.png", 64, 128);
		
		animation_left = new Animation(player_left, 250);
		animation_right = new Animation(player_right, 250);
	}
	
	
	@Override
	public void update(int delta) {
		animation_left.update(delta);
		animation_right.update(delta);
		temp1 = (int) (x +4 + (Math.signum(xVel) * 6));
		temp2 = (int) (y);
		boundingBox.setX(temp1);
		boundingBox.setY(temp2);
		Input input = container.getInput();
		left = input.isKeyDown(input.KEY_LEFT);
		down = input.isKeyDown(input.KEY_DOWN);
		right = input.isKeyDown(input.KEY_RIGHT);
		up = input.isKeyPressed(input.KEY_UP);
		if (intersects(item) && item.getType() == 0 && count == 0) {
			JumpHeight+=5;
			TopSpeed+=5;
			count = 1;
		} else if (intersects(item) && item.getType() == 1 && count == 0) {
			DoubleJumps++;
			count = 1;
			JumpHeight+=5;
			TopSpeed+=5;
		} 
		move();
		
	}
	@Override 
	public void render(Graphics g) {
		
		if (direction == null) {
			player_right.startUse();
			player_right.getSubImage(0,0).drawEmbedded(x, y, 32, 64);
			player_right.endUse();
		} else if (direction == true) {
			animation_left.draw(x, y, 32, 64);
		} else {
			animation_right.draw(x, y, 32, 64);
		}
		
		
	}
	
	public void move() {
		yMove();
		xMove();
		
	}
	
	public void xMove() {
		
		if((left && right) || (!left && !right)) {
			xVel*=0.8;
		} else if(left && !right) {
			direction = true;
			xVel-=Speed;
		} else if (right && !left) {
			direction = false;
			xVel+=Speed;
		} 
		if(xVel > 0 && xVel < 0.75) {
			xVel = 0;
			direction = null;
		}
		if(xVel < 0 && xVel > -0.75) {
			direction = null;
			xVel = 0;
		}
		
		if(xVel > TopSpeed) xVel = TopSpeed;
		if(xVel < -TopSpeed) xVel = -TopSpeed;
		
		boundingBox.setX(x + xVel);
		for(Entity tile: TileList) {
			if(intersects(tile)) {
				boundingBox.setX(x - xVel);
				while(!intersects(tile)) boundingBox.setX(boundingBox.getX()+ Math.signum(xVel)); 
				boundingBox.setX(boundingBox.getX()-Math.signum(xVel));
				xVel = 0;
				x = boundingBox.getX();	
			}
		}
		if (x < 0) {
			direction = null;
			x = 0;
			xVel = 0;
		}
		
		
		x += xVel;
	}
	
	public void yMove() {
		
		if (up) {
			if (JumpCount == DoubleJumps) {
				boundingBox.setY(boundingBox.getY()+1);
				for(int i = 0; i < TileList.size(); i++) {
					if (intersects(TileList.get(i))) {
						JumpCount = 0;
						yVel = -JumpHeight;
					}
				}
				boundingBox.setY(boundingBox.getY()-1);
			} else {
				yVel = -JumpHeight;
				JumpCount++;
			}
			
		}
		yVel += 1;
		boundingBox.setY(y + yVel);
		for(Entity tile: TileList) {
			if(intersects(tile)) {
				boundingBox.setY(y - yVel);
				while(!intersects(tile)) boundingBox.setY(boundingBox.getY()+ Math.signum(yVel)); 
				boundingBox.setY(boundingBox.getY()-Math.signum(yVel));
				yVel = 0;
				y = boundingBox.getY();	
			}
		}
		
		
		y += yVel;
	}
	
	public boolean intersects(Entity entity) {
	    if (this.getBoundingBox() == null) {
	        return false;
	    }
	    return this.getBoundingBox().intersects(entity.getBoundingBox());
	}
	
}
